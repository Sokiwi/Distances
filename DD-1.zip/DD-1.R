# This requires the following packages to have been installed:
# igraph, deldir, argosfilter.
# The following three files should be in the working directory:
# g2.RData, weights.RData, delaunay_graph.RData.
# Read in the function (Edit > Select all).
# Run it by typing DDone(Ala,Alo,Bla,Blo), where Ala and Alo are latitude
# and longitude of the origin and Bla and Blo lat and long of the destination.
# Coordinates should be in decimal degrees.
# Output is the distance rounded off to an integer.

DDone <- function(Ala,Alo,Bla,Blo) {
	library(igraph) # for shortest path
	library(deldir) # for Delaunay
	library(argosfilter) # for computing great circle distances
	load("g2.RData") # object g2
	load("weights.RData") # object w
	load("delaunay_graph.RData") # object gr
	
	dist_w_start <- as.vector(apply(g2, 1, function(z) distance(z[1], Ala, z[2], Alo)))
	dist_w_end <- as.vector(apply(g2, 1, function(z) distance(z[1], Bla, z[2], Blo)))
	ns <- g2[order(dist_w_start)[1:8],] # eight nearest start
	ne <- g2[order(dist_w_end)[1:8],] # eight nearest end
	d_start_cand_end <- rep(0, 8)
	for (i in 1:8) {
		d_start_cand_end[i] <- distance(Ala, ns[i,1], Alo, ns[i,2]) + distance(ns[i,1],Bla,ns[i,2],Blo)
	}
	p <- which(d_start_cand_end==min(d_start_cand_end))
	d_cand_end <- rep(0, 8)
	for (i in 1:8) {
		d_cand_end[i] <- distance(ne[i,1], Bla, ne[i,2], Blo)
	}
	q <- which(d_cand_end==min(d_cand_end))
	as <- distance(Ala, ns[p,1], Alo, ns[p,2]) # add to start
	ae <- distance(Bla, ne[q,1], Blo, ne[q,2]) # add to start
	start <- as.numeric(rownames(ns[p,]))
	end <- as.numeric(rownames(ne[q,]))
	s <- shortest.paths(gr, start, end, algorithm="dijkstra", weights=w)
	total <- round(s[1,1] + as + ae)
	return(total)
}

